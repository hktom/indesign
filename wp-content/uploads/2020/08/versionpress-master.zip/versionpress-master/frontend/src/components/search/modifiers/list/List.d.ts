/// <reference path='../../Search.d.ts' />

type GroupedItem = {
  section: string;
  priority: number;
  list: SearchConfigItemContent[];
};

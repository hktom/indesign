# VersionPress frontend

The UI of VersionPress is implemented as a React single-page application. See [Dev-Setup](../docs/content/en/developer/dev-setup.md) for more.

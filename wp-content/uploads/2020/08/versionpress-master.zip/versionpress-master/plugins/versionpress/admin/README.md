# VersionPress admin pages

Make sure to update `vp_admin_menu()` action to make the pages accessible.